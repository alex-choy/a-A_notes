def conjunct_select(arr, *procs)
  new_arr = []
  arr.each do |ele|
    procs.all? do |prc|
      new_arr << ele if prc.call(ele)
    end 
  end
  new_arr.uniq
end