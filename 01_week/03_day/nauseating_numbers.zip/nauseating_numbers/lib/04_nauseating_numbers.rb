###############################
##### Mersenne Prime
def mersenne_prime(num)
  return 0 if num < 1
  count = 1
  exponent = 2  # started w/ 2^2 - 1 = 3, which is in m_primes

  while count < num
    exponent += 1
    curr_prod = (2 ** exponent) - 1
    # keep checking until we have a non-prime prod
    while !is_prime?(curr_prod)
      exponent += 1
      curr_prod = (2 ** exponent) - 1
    end
    count += 1
  end
  2 ** exponent - 1
end

def is_prime?(n)
  return false if n < 2
  (2...n).none? { |i| n % i == 0 }
end

##############################
##### Triangular word
def triangular_word?(str)
  alpha = "0abcdefghijklmnopqrstuvwxyz"
  # str_sum = 0
  # str.each_char do |char|
  #   str_sum += alpha.index(char)
  # end
  str_sum = str.split("").map { |c| alpha.index(c) }.sum

  # mul by 2 to move the /2 from the equation
  is_triangular?(str_sum * 2)
end

def is_triangular?(str_sum)
  i = 1
  while (i * (i + 1)) <= str_sum
    return true if (i * (i + 1)) == str_sum
    i += 1
  end
  false
end

################################
##### Consecutive Collapse

def consecutive_collapse(arr)
  collapsed = false
  while !collapsed
    collapsed = true
    new_res = []
    i = 0
    while i < arr.length
      if consecutive?(arr[i], arr[i + 1])
        i += 1 # skips the next number, not added to new_res
        collapsed = false
      else
        new_res << arr[i]
      end
      i += 1
    end
    arr = new_res
  end
  arr
end

def consecutive?(num, right)
  num - 1 == right || num + 1 == right
end

################################
##### Pretentious Primes

# def pretentious_primes(arr, steps)
#   arr.map do |num|
#     temp = num
#     if steps > 0
#       steps.times do
#         temp += 1
#         while !is_prime?(temp)
#           temp += 1
#         end
#       end
#     else
#       rev_steps = -steps
#       rev_steps.times do
#         temp -= 1
#         while !is_prime?(temp)
#           temp -= 1
#           break if temp < 2
#         end
#       end
#     end
#     if temp < 2
#       nil
#     else
#       temp
#     end
#   end
# end

def next_prime(num, steps)
  i = 1

  # reverses the steps if negative
  if steps < 0
    i = -(i)
    steps = -(steps)
  end

  counter = 0
  while counter < steps
    # checks for going to -ve #s
    return nil if num < 2
    num += i
    counter += 1 if is_prime?(num)
  end
  num
end

def pretentious_primes(arr, steps)
  arr.map { |ele| next_prime(ele, steps) }
end
